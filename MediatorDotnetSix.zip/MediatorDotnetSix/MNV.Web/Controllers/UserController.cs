﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MNV.Commands.User;
using MNV.Domain.Models.Queries;
using MNV.Domain.Models.User;
using MNV.Queries.User;

namespace MNV.Web.Controllers
{
    public class UserController : BaseController
    {
        #region Constructor(s)
        public UserController(IMediator mediator)  : base (mediator)
        {
        }
        #endregion


        #region IActionResult(s)
        [HttpGet("values")]
        public IActionResult Index()
        {

            return  Ok(new { message = "" });
        }

        [HttpGet("get-all"), AllowAnonymous]
        public async Task<IActionResult> GetAll(int? page = null, int? pagesize = null)
        {
            var data = await _mediator.Send(new GetAllUser.Query { Paging = new PagingModel { Page = page ?? 0, PageSize = pagesize ?? 0 } });
            return Ok(data);
        }

        [HttpGet("get-by-id/{id}"), AllowAnonymous]
        public async Task<IActionResult> GetById (long id)
        {
            var data = await _mediator.Send(new GetUserById.Query(id));
            return Ok(data);
        }

        [HttpPost("create"), AllowAnonymous]
        public async Task<IActionResult> Create(UserViewModel model)
        {
            var data = await _mediator.Send(new CreateUser.Command(model));
            return Ok(data);
        }
        #endregion
    }
}
