﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MNV.Domain.Models.Queries
{
    public class SortModel
    {
        public bool SortAscending { get; set; }
        public string SortName { get; set; }
    }
}
