﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MNV.Domain.Constants
{
    public static class ConfigurationConstants
    {
        public const string AppSettings = "AppSettings";
        public const string ConnectionStrings = "ConnectionStrings";
    }
}
