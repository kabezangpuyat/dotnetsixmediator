﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MNV.Domain.ConfigSections
{
    public class ConnectionStrings
    {
        public string WebApiConnection { get; set; }
    }
}
